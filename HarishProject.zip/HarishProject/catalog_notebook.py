# Databricks notebook source
# MAGIC %md
# MAGIC ### Create Catalog

# COMMAND ----------

# MAGIC %sql
# MAGIC Create catalog cars_catalog

# COMMAND ----------

# MAGIC %md
# MAGIC ### create schema

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema cars_catalog.silver
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema cars_catalog.gold