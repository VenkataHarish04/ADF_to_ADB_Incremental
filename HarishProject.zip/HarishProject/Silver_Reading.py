# Databricks notebook source
# MAGIC %md
# MAGIC ### Data **Reading**

# COMMAND ----------

df = spark.read.format("parquet")\
            .option('inferSchema', True)\
              .load('abfss://bronze@anshdatar.dfs.core.windows.net/rawdata')

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data Transformantion

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

from pyspark.sql.functions import split, col

df = df.withColumn(
    'model_category',
    split(col('Model_ID'), '-').getItem(0)
)

# COMMAND ----------

df.display()

# COMMAND ----------

df_read = df.withColumn('Units_Sold', col('Units_Sold').cast(StringType()))


# COMMAND ----------

df_read.printSchema()

# COMMAND ----------

df = df.withColumn('unit_price', col('Revenue')/col('Units_Sold'))
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### ad-hoc analysis

# COMMAND ----------

df.groupBy('Year','BranchName').agg(sum('Units_Sold').alias('Total_Units')).sort('year','Total_Units',ascending=[1,0]).display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Data writing

# COMMAND ----------

df.write.format('parquet')\
    .mode('overwrite')\
        .option('path','abfss://silver@anshdatar.dfs.core.windows.net/carsales')\
            .save()