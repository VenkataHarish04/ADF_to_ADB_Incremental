# Databricks notebook source
# MAGIC %md
# MAGIC ### CREATE FACT Table

# COMMAND ----------

df_silver = spark.sql('''select * from parquet.`abfss://silver@anshdatar.dfs.core.windows.net/carsales`''')
df_silver.display()

# COMMAND ----------

df_dealer = spark.sql('select * from cars_catalog.gold.dim_dealer')
df_date = spark.sql('select * from cars_catalog.gold.dim_date')
df_branch = spark.sql('select * from cars_catalog.gold.branch')
df_model = spark.sql('select * from cars_catalog.gold.dim_model')


# COMMAND ----------

# MAGIC %md
# MAGIC ### Brininging Keys to the fact Table

# COMMAND ----------

df_fact = df_silver.join(df_branch,df_silver['Branch_ID'] == df_branch['Branch_ID'],'left')\
                   .join(df_dealer,df_silver['Dealer_ID'] == df_dealer['Dealer_ID'],'left')\
                    .join(df_model,df_silver['Model_ID'] == df_model['Model_ID'],'left')\
                      .join(df_date,df_silver['Date_ID'] == df_date['Date_ID'],'left').select(df_silver['Revenue'],df_silver['unit_price'],df_branch['dim_branch_key'],df_dealer['dim_dealer_key'],df_model['dim_model_key'],df_date['dim_Date_key'])

# COMMAND ----------

df_fact.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing Fatc Table

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

if spark.catalog.tableExists('cars_catalog.gold.fact'):
    delta_table = DeltaTable.forName(
        spark,
        'cars_catalog.gold.fact'
    )
    delta_table.alias('t').merge(
        df_fact.alias('s'),
        't.dim_branch_key = s.dim_branch_key and t.dim_dealer_key = s.dim_dealer_key and t.dim_model_key = s.dim_model_key and t.dim_Date_key = s.dim_Date_key'
    ).whenMatchedUpdateAll(
    ).whenNotMatchedInsertAll(
    ).execute()
else:
    df_fact.write.format('delta'
    ).mode('overwrite'
    ).option(
        'path',
        'abfss://gold@anshdatar.dfs.core.windows.net/fact'
    ).saveAsTable(
        'cars_catalog.gold.fact'
    )

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cars_catalog.gold.fact