# Databricks notebook source
# MAGIC %md
# MAGIC ### Cretae Flag Parameter

# COMMAND ----------

dbutils.widgets.text('incremental_flag','0')

# COMMAND ----------

incremental_flag = dbutils.widgets.get('incremental_flag')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating Dimension Model

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from parquet.`abfss://silver@anshdatar.dfs.core.windows.net/carsales`

# COMMAND ----------

df_src = spark.sql('''
  select distinct(Dealer_ID), DealerName from parquet.`abfss://silver@anshdatar.dfs.core.windows.net/carsales`
  ''')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Dim_model_Sink_intial and incremental

# COMMAND ----------

if not spark.catalog.tableExists('cars_catalog.gold.dim_dealer'):

    df_sink = spark.sql('''
    select 1 as dim_Dealer_key,Dealer_ID, DealerName from parquet.`abfss://silver@anshdatar.dfs.core.windows.net/carsales`
    where 1 = 0
    ''')
else:
    df_sink = spark.sql('''
    select  dim_Dealer_key,Dealer_ID, DealerName from cars_catalog.gold.dim_dealer

    ''')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Filtering new records and old records

# COMMAND ----------

df_filter = df_src.join(
    df_sink,
    df_src["Dealer_ID"] == df_sink["Dealer_ID"],
    "left"
).select(
    df_src["Dealer_ID"],
    df_src["DealerName"],
    df_sink["dim_Dealer_key"]
)
display(df_filter)

# COMMAND ----------

# MAGIC %md
# MAGIC ### df_filter_old

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

df_filter_old = df_filter.filter(col('dim_Dealer_key').isNotNull())
df_filter_new = df_filter.filter(col('dim_Dealer_key').isNull())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Surrogate Key

# COMMAND ----------

if incremental_flag == '0':
    max_value = 1
else:
    max_value_df = spark.sql("select max(dim_Dealer_key) from cars_catalog.gold.dim_dealer")
    max_value = max_value_df.collect()[0][0]

# COMMAND ----------

df_filter_new = df_filter_new.withColumn('dim_Dealer_key',lit(max_value)+monotonically_increasing_id())

# COMMAND ----------

df_filter_new.display()

# COMMAND ----------

df_final = df_filter_old.union(df_filter_new)
df_final.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### SCD - Type 1

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

if spark.catalog.tableExists('cars_catalog.gold.dim_dealer'):
    delta_tbl = DeltaTable.forPath(spark,'abfss://gold@anshdatar.dfs.core.windows.net/dim_dealer')
    delta_tbl.alias('t').merge(
        df_final.alias('s'),
        't.Dealer_ID = s.Dealer_ID'
    ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

else:
    df_final.write.format('delta')\
        .mode('overwrite')\
        .option('path','abfss://gold@anshdatar.dfs.core.windows.net/dim_dealer')\
            .saveAsTable('cars_catalog.gold.dim_dealer')


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cars_catalog.gold.dim_dealer